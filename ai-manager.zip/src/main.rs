use md5::{Digest, Md5};
use serde::Deserialize;
use slint::{Color, SharedString};
use std::collections::{HashMap, HashSet};
use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant, UNIX_EPOCH};
use sysinfo::System;
use winreg::enums::*;
use winreg::RegKey;
use wmi::{COMLibrary, WMIConnection};

slint::include_modules!();

const EMBEDDED_JSON: &str = include_str!("../models.json");
const REGISTRY_PATH: &str = r#"Software\Gallery Inc\AIModelManager"#;
const MODELS_REGISTRY_PATH: &str = r#"Software\Gallery Inc\AIModelManager\Models"#;
const LEGACY_REGISTRY_PATH: &str = r#"Software\Gallery Inc\AI-ModelsManager"#;
const DEFAULT_FALLBACK_PATH: &str = r#"H:\AI_Models\ioscap"#;
const GITHUB_URL: &str = "https://github.com/ionuttbara/onnxaimanager";
const DOWNLOAD_MODELS_URL: &str = "https://k00.fr/aimodels";
const IO_BUFFER_SIZE: usize = 4 * 1024 * 1024;
const PROGRESS_INTERVAL: Duration = Duration::from_millis(80);

// ============================================================================
// Model & Manifest Structures
// ============================================================================

#[derive(Deserialize, Debug, Clone)]
pub struct RawAiModel {
    pub md5: String,
    pub name: String,
    pub model_type: String,
    pub used_for: String,
    #[serde(default)]
    pub supports: Vec<String>,
    pub size_bytes: u64,
    #[serde(default = "default_author")]
    pub author: String,
}

#[derive(Clone, Debug)]
pub struct AiModel {
    pub id: String,
    pub name: String,
    pub model_type: String,
    pub used_for: String,
    pub supports: Vec<String>,
    pub size_bytes: u64,
    pub author: String,
    pub expected_md5: String,
}

#[derive(Clone, Debug)]
pub struct InstalledModel {
    pub name: String,
    pub model_type: String,
    pub used_for: String,
    pub supports: Vec<String>,
    pub size_bytes: u64,
    pub author: String,
}

#[derive(Debug)]
pub struct ReconcileResult {
    pub installed: Vec<InstalledModel>,
    pub total_bytes: u64,
}

#[derive(Debug)]
pub struct RegistryRecord {
    pub file_name: String,
    pub full_path: String,
    pub md5_value: String,
    pub size_bytes: u64,
    pub last_write_token: String,
    pub status: String,
}

fn default_author() -> String {
    "Unknown".to_string()
}

fn format_size(bytes: u64) -> String {
    const MB: f64 = 1_048_576.0;
    const GB: f64 = 1_073_741_824.0;

    if bytes as f64 >= GB {
        format!("{:.2} GB", bytes as f64 / GB)
    } else {
        format!("{:.2} MB", bytes as f64 / MB)
    }
}

// ============================================================================
// Class: ManifestManager
// ============================================================================

pub struct ManifestManager {
    models: Vec<AiModel>,
    by_name: HashMap<String, usize>,
    by_md5: HashMap<String, usize>,
}

impl ManifestManager {
    pub fn load_from_embedded() -> (Self, Vec<String>) {
        let mut warnings = Vec::new();
        let raw_models: Vec<RawAiModel> = match serde_json::from_str(EMBEDDED_JSON) {
            Ok(models) => models,
            Err(error) => {
                warnings.push(format!("Failed to parse embedded manifest: {error}"));
                Vec::new()
            }
        };

        let mut models = Vec::new();
        let mut by_name = HashMap::new();
        let mut by_md5 = HashMap::new();
        let mut seen_names = HashSet::new();

        for (index, raw) in raw_models.into_iter().enumerate() {
            let name = raw.name.trim().to_string();
            let md5_val = raw.md5.trim().to_ascii_lowercase();

            if name.is_empty() || md5_val.is_empty() {
                warnings.push(format!("Entry #{index} skipped: missing name or MD5"));
                continue;
            }

            if !Self::is_valid_md5(&md5_val) {
                warnings.push(format!("Entry '{name}' skipped: invalid MD5 hash format"));
                continue;
            }

            let normalized_name = name.to_ascii_lowercase();
            if !seen_names.insert(normalized_name.clone()) {
                warnings.push(format!("Entry '{name}' skipped: duplicate file name"));
                continue;
            }

            let id = Self::derive_id(&name);
            let model = AiModel {
                id,
                name: name.clone(),
                model_type: raw.model_type.trim().to_string(),
                used_for: raw.used_for.trim().to_string(),
                supports: raw.supports.into_iter().map(|s| s.trim().to_ascii_lowercase()).filter(|s| !s.is_empty()).collect(),
                size_bytes: raw.size_bytes,
                author: if raw.author.trim().is_empty() { default_author() } else { raw.author.trim().to_string() },
                expected_md5: md5_val.clone(),
            };

            let pos = models.len();
            by_name.insert(normalized_name, pos);
            by_md5.insert(md5_val, pos);
            models.push(model);
        }

        (Self { models, by_name, by_md5 }, warnings)
    }

    pub fn find_by_md5(&self, md5_hash: &str) -> Option<&AiModel> {
        self.by_md5.get(&md5_hash.to_ascii_lowercase()).and_then(|idx| self.models.get(*idx))
    }

    pub fn find_by_name(&self, name: &str) -> Option<&AiModel> {
        self.by_name.get(&name.to_ascii_lowercase()).and_then(|idx| self.models.get(*idx))
    }

    pub fn models(&self) -> &[AiModel] {
        &self.models
    }

    fn is_valid_md5(val: &str) -> bool {
        val.len() == 32 && val.bytes().all(|b| b.is_ascii_hexdigit())
    }

    fn derive_id(file_name: &str) -> String {
        let stem = Path::new(file_name).file_stem().and_then(|s| s.to_str()).unwrap_or(file_name);
        stem.chars()
            .map(|c| if c.is_ascii_alphanumeric() { c.to_ascii_lowercase() } else { '-' })
            .collect::<String>()
            .trim_matches('-')
            .to_string()
    }
}

// ============================================================================
// Class: StorageRegistry
// ============================================================================

pub struct StorageRegistry {
    app_key: RegKey,
    models_key: RegKey,
}

impl StorageRegistry {
    pub fn open() -> io::Result<Self> {
        let hkcu = RegKey::predef(HKEY_CURRENT_USER);
        let (app_key, _) = hkcu.create_subkey(REGISTRY_PATH)?;
        let (models_key, _) = hkcu.create_subkey(MODELS_REGISTRY_PATH)?;

        let _ = app_key.set_value("AppVersion", &env!("CARGO_PKG_VERSION"));

        Ok(Self { app_key, models_key })
    }

    pub fn get_saved_location() -> Option<PathBuf> {
        if let Ok(store) = Self::open() {
            if let Ok(location) = store.app_key.get_value::<String, _>("ModelRoot") {
                let path = PathBuf::from(location);
                if path.is_dir() {
                    return Some(path);
                }
            }
        }

        for hive in [HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE] {
            let root = RegKey::predef(hive);
            if let Ok(key) = root.open_subkey(LEGACY_REGISTRY_PATH) {
                if let Ok(location) = key.get_value::<String, _>("location") {
                    let path = PathBuf::from(location);
                    if path.is_dir() {
                        let _ = Self::save_location(&path);
                        return Some(path);
                    }
                }
            }
        }

        let fallback = PathBuf::from(DEFAULT_FALLBACK_PATH);
        if fallback.is_dir() {
            let _ = Self::save_location(&fallback);
            return Some(fallback);
        }

        None
    }

    pub fn save_location(path: &Path) -> io::Result<()> {
        let store = Self::open()?;
        store.app_key.set_value("ModelRoot", &path.to_string_lossy().to_string())
    }

    pub fn read_model(&self, model_id: &str) -> io::Result<Option<RegistryRecord>> {
        let key = match self.models_key.open_subkey(model_id) {
            Ok(k) => k,
            Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(e),
        };

        Ok(Some(RegistryRecord {
            file_name: key.get_value("FileName")?,
            full_path: key.get_value("FullPath")?,
            md5_value: key.get_value("MD5")?,
            size_bytes: key.get_value("SizeBytes")?,
            last_write_token: key.get_value("LastWriteToken")?,
            status: key.get_value("Status")?,
        }))
    }

    pub fn write_model(&self, model: &AiModel, full_path: &Path, metadata: &fs::Metadata, md5_hash: &str) -> io::Result<()> {
        let (key, _) = self.models_key.create_subkey(&model.id)?;
        let norm_path = fs::canonicalize(full_path).unwrap_or_else(|_| full_path.to_path_buf()).to_string_lossy().to_string();
        let modified_token = metadata.modified().ok()
            .and_then(|m| m.duration_since(UNIX_EPOCH).ok())
            .map(|d| d.as_nanos().to_string())
            .unwrap_or_else(|| "0".to_string());

        key.set_value("FileName", &model.name)?;
        key.set_value("FullPath", &norm_path)?;
        key.set_value("MD5", &md5_hash)?;
        key.set_value("SizeBytes", &metadata.len())?;
        key.set_value("LastWriteToken", &modified_token)?;
        key.set_value("Status", &"Verified")?;
        Ok(())
    }

    pub fn remove_model(&self, model_id: &str) -> io::Result<()> {
        match self.models_key.delete_subkey_all(model_id) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(e),
        }
    }

    pub fn cleanup_orphans(&self, valid_ids: &HashSet<String>) -> io::Result<()> {
        let keys: Vec<String> = self.models_key.enum_keys().filter_map(Result::ok).collect();
        for key in keys {
            if !valid_ids.contains(&key) {
                let _ = self.remove_model(&key);
            }
        }
        Ok(())
    }
}

// ============================================================================
// Class: SystemInspector
// ============================================================================

#[derive(Deserialize, Debug)]
#[serde(rename_all = "PascalCase")]
struct VideoControllerWmi {
    name: String,
    driver_version: Option<String>,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "PascalCase")]
struct PnPSignedDriverWmi {
    device_name: Option<String>,
    driver_version: Option<String>,
    manufacturer: Option<String>,
}

#[derive(Deserialize, Debug)]
#[serde(rename_all = "PascalCase")]
struct PnPEntityWmi {
    name: Option<String>,
    manufacturer: Option<String>,
}

pub struct SysInfoData {
    pub general: String,
    pub gpu: String,
    pub npu: String,
}

pub struct SystemInspector;

impl SystemInspector {
    pub fn inspect() -> SysInfoData {
        let mut general = String::new();
        let mut gpu = String::new();
        let mut npu = String::new();

        let mut sys = System::new_all();
        sys.refresh_all();

        let cpu = sys.cpus().first().map(|c| c.brand().trim()).unwrap_or("Unknown CPU");
        let ram_gb = sys.total_memory() as f64 / 1_073_741_824.0;

        general.push_str(&format!("Application:\n- AI Models Manager: v{}\n\n", env!("CARGO_PKG_VERSION")));
        general.push_str(&format!("Core Hardware:\n- CPU: {cpu}\n- RAM: {ram_gb:.1} GB\n"));

        match COMLibrary::new() {
            Ok(com) => match WMIConnection::new(com) {
                Ok(wmi) => {
                    Self::query_gpus(&wmi, &mut gpu);
                    Self::query_npus(&wmi, &mut npu);
                }
                Err(e) => {
                    let err_msg = format!("- WMI Init failed: {e}\n");
                    gpu.push_str(&err_msg);
                    npu.push_str(&err_msg);
                }
            },
            Err(e) => {
                let err_msg = format!("- COM Init failed: {e}\n");
                gpu.push_str(&err_msg);
                npu.push_str(&err_msg);
            }
        }

        Self::query_cuda(&mut gpu);

        SysInfoData { general, gpu, npu }
    }

    fn query_gpus(wmi: &WMIConnection, info: &mut String) {
        let mut found = false;
        if let Ok(gpus) = wmi.raw_query::<VideoControllerWmi>("SELECT Name, DriverVersion FROM Win32_VideoController") {
            for gpu in gpus {
                found = true;
                let driver = gpu.driver_version.unwrap_or_else(|| "Unknown".to_string());
                info.push_str(&format!("- Graphic Adapter: {} (Driver: {})\n", gpu.name, driver));
                info.push_str("  [ONNX DirectML Capabilities: FP32, FP16, INT32, INT16, INT8, INT8 Quantized via D3D12 DP4a]\n\n");
            }
        }
        if !found {
            info.push_str("- GPU: Not detected via WMI.\n\n");
        }
    }

    fn query_npus(wmi: &WMIConnection, info: &mut String) {
        let mut found_npus = HashSet::new();
        let mut found = false;

        let driver_query = "SELECT DeviceName, DriverVersion, Manufacturer FROM Win32_PnPSignedDriver WHERE DeviceName LIKE '%NPU%' OR DeviceName LIKE '%Neural%'";
        if let Ok(drivers) = wmi.raw_query::<PnPSignedDriverWmi>(driver_query) {
            for drv in drivers {
                if let Some(name) = drv.device_name {
                    let name_lower = name.to_ascii_lowercase();
                    if !name_lower.contains("usb") && !name_lower.contains("input") {
                        let mfg = drv.manufacturer.unwrap_or_else(|| "Unknown Manufacturer".to_string());
                        let ver = drv.driver_version.unwrap_or_else(|| "Unknown Driver".to_string());
                        if found_npus.insert(name.clone()) {
                            found = true;
                            info.push_str(&format!("- Neural Processor: {} (Manufacturer: {}, Driver: {})\n", name, mfg, ver));
                            info.push_str("  [ONNX DirectML (MCDM) Capabilities: Optimized for INT8 Quantized TOPS, INT16, FP16. Non-quantized FP32/INT32 operations automatically delegate to fallback paths.]\n\n");
                        }
                    }
                }
            }
        }

        if !found {
            let entity_query = "SELECT Name, Manufacturer FROM Win32_PnPEntity WHERE Name LIKE '%NPU%' OR Name LIKE '%Neural%'";
            if let Ok(entities) = wmi.raw_query::<PnPEntityWmi>(entity_query) {
                for ent in entities {
                    if let Some(name) = ent.name {
                        let name_lower = name.to_ascii_lowercase();
                        if !name_lower.contains("usb") && !name_lower.contains("input") {
                            let mfg = ent.manufacturer.unwrap_or_else(|| "Unknown Manufacturer".to_string());
                            if found_npus.insert(name.clone()) {
                                found = true;
                                info.push_str(&format!("- Neural Processor: {} (Manufacturer: {})\n", name, mfg));
                                info.push_str("  [ONNX DirectML (MCDM) Capabilities: Optimized for INT8 Quantized TOPS, INT16, FP16. Non-quantized FP32/INT32 operations automatically delegate to fallback paths.]\n\n");
                            }
                        }
                    }
                }
            }
        }

        if !found {
            info.push_str("- NPU: Not detected.\n");
        }
    }

    fn query_cuda(info: &mut String) {
        info.push_str("CUDA & AI Runtime Environment:\n");
        match cuda_driver::query_cuda_driver_version() {
            Ok(v) => info.push_str(&format!("- NVIDIA CUDA Driver API Level: {v}\n")),
            Err(e) => info.push_str(&format!("- NVIDIA CUDA: Not available ({e})\n")),
        }
    }
}

// ============================================================================
// Class: ModelDeploymentService
// ============================================================================

pub struct ModelDeploymentService;

impl ModelDeploymentService {
    pub fn compute_md5<F>(path: &Path, mut progress: F) -> io::Result<String>
    where
        F: FnMut(f32),
    {
        let metadata = fs::metadata(path)?;
        let total_size = metadata.len();
        let denominator = total_size.max(1) as f64;

        let mut file = File::open(path)?;
        let mut md5_context = Md5::new();
        let mut buffer = vec![0_u8; IO_BUFFER_SIZE];
        let mut processed = 0_u64;
        let mut last_emit = Instant::now() - PROGRESS_INTERVAL;

        loop {
            let bytes_read = file.read(&mut buffer)?;
            if bytes_read == 0 {
                break;
            }
            md5_context.update(&buffer[..bytes_read]);
            processed = processed.saturating_add(bytes_read as u64);

            if last_emit.elapsed() >= PROGRESS_INTERVAL {
                progress((processed as f64 / denominator) as f32);
                last_emit = Instant::now();
            }
        }

        progress(1.0);
        Ok(hex::encode(md5_context.finalize()))
    }

    pub fn copy_file_computing_md5<F>(source: &Path, destination: &Path, mut progress: F) -> io::Result<String>
    where
        F: FnMut(f32),
    {
        let metadata = fs::metadata(source)?;
        let total_size = metadata.len();
        let denominator = total_size.max(1) as f64;

        if destination.exists() {
            fs::remove_file(destination)?;
        }

        let mut input = File::open(source)?;
        let mut output = OpenOptions::new().create_new(true).write(true).open(destination)?;
        let mut md5_context = Md5::new();
        let mut buffer = vec![0_u8; IO_BUFFER_SIZE];
        let mut processed = 0_u64;
        let mut last_emit = Instant::now() - PROGRESS_INTERVAL;

        loop {
            let bytes_read = input.read(&mut buffer)?;
            if bytes_read == 0 {
                break;
            }
            output.write_all(&buffer[..bytes_read])?;
            md5_context.update(&buffer[..bytes_read]);
            processed = processed.saturating_add(bytes_read as u64);

            if last_emit.elapsed() >= PROGRESS_INTERVAL {
                progress((processed as f64 / denominator) as f32);
                last_emit = Instant::now();
            }
        }

        output.flush()?;
        output.sync_all()?;
        progress(1.0);

        Ok(hex::encode(md5_context.finalize()))
    }

    pub fn reconcile<F>(root: &Path, manifest: &ManifestManager, mut progress: F) -> io::Result<ReconcileResult>
    where
        F: FnMut(String, f32),
    {
        if !root.is_dir() {
            return Err(io::Error::new(io::ErrorKind::NotFound, "Folder not found"));
        }

        let store = StorageRegistry::open()?;
        store.app_key.set_value("ModelRoot", &root.to_string_lossy().to_string())?;

        let mut installed = Vec::new();
        let mut total_bytes = 0_u64;
        let mut verified_ids = HashSet::new();
        let model_count = manifest.models().len().max(1) as f32;

        for (idx, model) in manifest.models().iter().enumerate() {
            let base_progress = idx as f32 / model_count;
            progress(format!("Checking {}...", model.name), base_progress);

            let file_path = root.join(&model.name);
            if !file_path.is_file() {
                let _ = store.remove_model(&model.id);
                continue;
            }

            let metadata = fs::metadata(&file_path)?;
            let modified_token = metadata.modified().ok()
                .and_then(|m| m.duration_since(UNIX_EPOCH).ok())
                .map(|d| d.as_nanos().to_string())
                .unwrap_or_default();

            let cached = store.read_model(&model.id)?;
            let is_cache_valid = cached.as_ref().map(|rec| {
                rec.status.eq_ignore_ascii_case("Verified")
                    && rec.md5_value.eq_ignore_ascii_case(&model.expected_md5)
                    && rec.last_write_token == modified_token
            }).unwrap_or(false);

            if !is_cache_valid {
                let calculated_md5 = Self::compute_md5(&file_path, |p| {
                    progress(format!("Hashing {}...", model.name), base_progress + p / model_count);
                })?;

                if !calculated_md5.eq_ignore_ascii_case(&model.expected_md5) {
                    let _ = store.remove_model(&model.id);
                    continue;
                }

                store.write_model(model, &file_path, &metadata, &calculated_md5)?;
            }

            verified_ids.insert(model.id.clone());
            total_bytes = total_bytes.saturating_add(metadata.len());
            installed.push(InstalledModel {
                name: model.name.clone(),
                model_type: model.model_type.clone(),
                used_for: model.used_for.clone(),
                supports: model.supports.clone(),
                size_bytes: metadata.len(),
                author: model.author.clone(),
            });
        }

        let _ = store.cleanup_orphans(&verified_ids);
        progress("Synchronization complete.".to_string(), 1.0);

        Ok(ReconcileResult { installed, total_bytes })
    }

    pub fn install<F>(source: &Path, root: &Path, model: &AiModel, mut progress: F) -> io::Result<()>
    where
        F: FnMut(String, f32),
    {
        fs::create_dir_all(root)?;
        let destination = root.join(&model.name);
        let temporary = root.join(format!("{}.part", model.name));

        progress("Copying model weights...".to_string(), 0.1);
        let calculated_md5 = match Self::copy_file_computing_md5(source, &temporary, |v| {
            progress("Copying and computing MD5...".to_string(), 0.1 + v * 0.75);
        }) {
            Ok(hash) => hash,
            Err(e) => {
                let _ = fs::remove_file(&temporary);
                return Err(e);
            }
        };

        if !calculated_md5.eq_ignore_ascii_case(&model.expected_md5) {
            let _ = fs::remove_file(&temporary);
            return Err(io::Error::new(io::ErrorKind::InvalidData, "MD5 mismatch: file corrupted or modified."));
        }

        if destination.exists() {
            let _ = fs::remove_file(&destination);
        }
        fs::rename(&temporary, &destination)?;

        let metadata = fs::metadata(&destination)?;
        let store = StorageRegistry::open()?;
        store.write_model(model, &destination, &metadata, &calculated_md5)?;

        progress("Model installed successfully.".to_string(), 1.0);
        Ok(())
    }

    pub fn remove(root: &Path, model: &AiModel) -> io::Result<()> {
        let path = root.join(&model.name);
        if path.exists() {
            fs::remove_file(path)?;
        }
        let store = StorageRegistry::open()?;
        store.remove_model(&model.id)
    }
}

// ============================================================================
// Class: AppController
// ============================================================================

pub struct AppController {
    manifest: Arc<ManifestManager>,
    warning: Arc<Mutex<Option<String>>>,
}

impl AppController {
    pub fn new() -> Self {
        let (manifest, warnings) = ManifestManager::load_from_embedded();
        let warn_msg = if warnings.is_empty() { None } else { Some(warnings.join("\n")) };
        Self {
            manifest: Arc::new(manifest),
            warning: Arc::new(Mutex::new(warn_msg)),
        }
    }

    pub fn run(self) -> Result<(), slint::PlatformError> {
        let ui = MainWindow::new()?;
        ui.set_accent_color(Self::get_accent_color());
        ui.set_models(Rc::new(slint::VecModel::from(Vec::<ModelInfo>::new())).into());
        ui.set_total_size_formatted(SharedString::from(format_size(0)));

        let location = StorageRegistry::get_saved_location();
        match &location {
            Some(path) => {
                ui.set_current_location(SharedString::from(path.to_string_lossy().to_string()));
                ui.set_show_oobe(false);
            }
            None => {
                ui.set_show_oobe(true);
            }
        }

        self.bind_events(&ui);

        if let Some(path) = location {
            self.trigger_reconcile(&ui, path);
        }

        ui.run()
    }

    fn get_accent_color() -> Color {
        let hkcu = RegKey::predef(HKEY_CURRENT_USER);
        if let Ok(dwm) = hkcu.open_subkey(r#"Software\Microsoft\Windows\DWM"#) {
            if let Ok(color_value) = dwm.get_value::<u32, _>("ColorizationColor") {
                return Color::from_rgb_u8(
                    ((color_value >> 16) & 0xFF) as u8,
                    ((color_value >> 8) & 0xFF) as u8,
                    (color_value & 0xFF) as u8,
                );
            }
        }
        Color::from_rgb_u8(0, 120, 215)
    }

    fn trigger_reconcile(&self, ui: &MainWindow, path: PathBuf) {
        let ui_weak = ui.as_weak();
        let manifest = Arc::clone(&self.manifest);
        let warning = Arc::clone(&self.warning);

        ui.set_progress_text(SharedString::from("Synchronizing AI models..."));
        ui.set_progress_value(0.0);
        ui.set_show_progress(true);

        thread::spawn(move || {
            let res = ModelDeploymentService::reconcile(&path, &manifest, |txt, val| {
                let ui_thread = ui_weak.clone();
                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(ui) = ui_thread.upgrade() {
                        ui.set_progress_text(SharedString::from(txt));
                        ui.set_progress_value(val);
                    }
                });
            });

            let _ = slint::invoke_from_event_loop(move || {
                if let Some(ui) = ui_weak.upgrade() {
                    ui.set_show_progress(false);
                    match res {
                        Ok(reconciled) => {
                            let rows: Vec<ModelInfo> = reconciled.installed.into_iter().map(|m| {
                                ModelInfo {
                                    name: SharedString::from(m.name),
                                    model_type: SharedString::from(m.model_type),
                                    used_for: SharedString::from(m.used_for),
                                    author: SharedString::from(m.author),
                                    size_formatted: SharedString::from(format_size(m.size_bytes)),
                                    supports: Rc::new(slint::VecModel::from(m.supports.into_iter().map(SharedString::from).collect::<Vec<_>>())).into(),
                                }
                            }).collect();
                            ui.set_models(Rc::new(slint::VecModel::from(rows)).into());
                            ui.set_total_size_formatted(SharedString::from(format_size(reconciled.total_bytes)));

                            if let Some(warn) = warning.lock().ok().and_then(|mut w| w.take()) {
                                ui.set_error_text(SharedString::from(warn));
                                ui.set_show_error(true);
                            }
                        }
                        Err(e) => {
                            ui.set_error_text(SharedString::from(format!("Reconciliation failed:\n{e}")));
                            ui.set_show_error(true);
                        }
                    }
                }
            });
        });
    }

    fn bind_events(&self, ui: &MainWindow) {
        ui.on_open_download_models(|| {
            let _ = std::process::Command::new("explorer.exe").arg(DOWNLOAD_MODELS_URL).spawn();
        });

        ui.on_open_link(|| {
            let _ = std::process::Command::new("explorer.exe").arg(GITHUB_URL).spawn();
        });

        {
            let ui_weak = ui.as_weak();
            ui.on_open_folder(move || {
                if let Some(ui) = ui_weak.upgrade() {
                    let path = PathBuf::from(ui.get_current_location().to_string());
                    if path.is_dir() {
                        let _ = std::process::Command::new("explorer.exe").arg(&path).spawn();
                    }
                }
            });
        }

        {
            let ui_weak = ui.as_weak();
            ui.on_request_sysinfo(move || {
                let ui_thread = ui_weak.clone();
                if let Some(ui) = ui_weak.upgrade() {
                    ui.set_progress_text(SharedString::from("Inspecting system hardware..."));
                    ui.set_progress_value(0.1);
                    ui.set_show_progress(true);
                }
                thread::spawn(move || {
                    let sysinfo_data = SystemInspector::inspect();
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = ui_thread.upgrade() {
                            ui.set_sysinfo_general(SharedString::from(sysinfo_data.general));
                            ui.set_sysinfo_gpu(SharedString::from(sysinfo_data.gpu));
                            ui.set_sysinfo_npu(SharedString::from(sysinfo_data.npu));
                            ui.set_show_progress(false);
                            ui.set_show_sysinfo(true);
                        }
                    });
                });
            });
        }

        {
            let ui_weak = ui.as_weak();
            let manifest = Arc::clone(&self.manifest);
            let warning = Arc::clone(&self.warning);

            ui.on_pick_oobe_folder(move || {
                let Some(ui) = ui_weak.upgrade() else { return; };
                if let Some(folder) = rfd::FileDialog::new().set_title("Choose AI Models Folder").pick_folder() {
                    let _ = StorageRegistry::save_location(&folder);
                    ui.set_current_location(SharedString::from(folder.to_string_lossy().to_string()));
                    ui.set_show_oobe(false);

                    let ui_thread = ui_weak.clone();
                    let m_clone = Arc::clone(&manifest);
                    let w_clone = Arc::clone(&warning);
                    thread::spawn(move || {
                        let res = ModelDeploymentService::reconcile(&folder, &m_clone, |_, _| {});
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(ui) = ui_thread.upgrade() {
                                if let Ok(reconciled) = res {
                                    let rows: Vec<ModelInfo> = reconciled.installed.into_iter().map(|m| {
                                        ModelInfo {
                                            name: SharedString::from(m.name),
                                            model_type: SharedString::from(m.model_type),
                                            used_for: SharedString::from(m.used_for),
                                            author: SharedString::from(m.author),
                                            size_formatted: SharedString::from(format_size(m.size_bytes)),
                                            supports: Rc::new(slint::VecModel::from(m.supports.into_iter().map(SharedString::from).collect::<Vec<_>>())).into(),
                                        }
                                    }).collect();
                                    ui.set_models(Rc::new(slint::VecModel::from(rows)).into());
                                    ui.set_total_size_formatted(SharedString::from(format_size(reconciled.total_bytes)));
                                }
                                if let Some(warn) = w_clone.lock().ok().and_then(|mut w| w.take()) {
                                    ui.set_error_text(SharedString::from(warn));
                                    ui.set_show_error(true);
                                }
                            }
                        });
                    });
                }
            });
        }

        {
            let ui_weak = ui.as_weak();
            let manifest = Arc::clone(&self.manifest);

            ui.on_verify_model(move || {
                let Some(ui) = ui_weak.upgrade() else { return; };
                let Some(selected) = rfd::FileDialog::new().add_filter("ONNX Model", &["onnx"]).pick_file() else { return; };

                ui.set_progress_text(SharedString::from("Computing MD5 checksum..."));
                ui.set_progress_value(0.0);
                ui.set_show_progress(true);

                let ui_thread = ui.as_weak();
                let m_clone = Arc::clone(&manifest);

                thread::spawn(move || {
                    let hash_res = ModelDeploymentService::compute_md5(&selected, |v| {
                        let ui_t = ui_thread.clone();
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(ui) = ui_t.upgrade() {
                                ui.set_progress_value(v);
                            }
                        });
                    });

                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = ui_thread.upgrade() {
                            ui.set_show_progress(false);
                            match hash_res {
                                Ok(md5_hash) => {
                                    if let Some(model) = m_clone.find_by_md5(&md5_hash) {
                                        ui.set_pending_model(ModelInfo {
                                            name: SharedString::from(model.name.clone()),
                                            model_type: SharedString::from(model.model_type.clone()),
                                            used_for: SharedString::from(model.used_for.clone()),
                                            author: SharedString::from(model.author.clone()),
                                            size_formatted: SharedString::from(format_size(model.size_bytes)),
                                            supports: Rc::new(slint::VecModel::from(model.supports.iter().cloned().map(SharedString::from).collect::<Vec<_>>())).into(),
                                        });
                                        ui.set_pending_file_path(SharedString::from(selected.to_string_lossy().to_string()));
                                        ui.set_show_install_confirm(true);
                                    } else {
                                        ui.set_error_text(SharedString::from("No match found in manifest for this MD5 checksum."));
                                        ui.set_show_error(true);
                                    }
                                }
                                Err(e) => {
                                    ui.set_error_text(SharedString::from(format!("Failed to calculate MD5:\n{e}")));
                                    ui.set_show_error(true);
                                }
                            }
                        }
                    });
                });
            });
        }

        {
            let ui_weak = ui.as_weak();
            let manifest = Arc::clone(&self.manifest);

            ui.on_confirm_install(move || {
                let Some(ui) = ui_weak.upgrade() else { return; };
                let source = PathBuf::from(ui.get_pending_file_path().to_string());
                let root = PathBuf::from(ui.get_current_location().to_string());
                let model_name = ui.get_pending_model().name.to_string();

                let Some(model) = manifest.find_by_name(&model_name).cloned() else {
                    ui.set_show_install_confirm(false);
                    return;
                };

                ui.set_show_install_confirm(false);
                ui.set_progress_text(SharedString::from("Installing model..."));
                ui.set_progress_value(0.0);
                ui.set_show_progress(true);

                let ui_thread = ui.as_weak();
                let m_clone = Arc::clone(&manifest);

                thread::spawn(move || {
                    let install_res = ModelDeploymentService::install(&source, &root, &model, |txt, val| {
                        let ui_t = ui_thread.clone();
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(ui) = ui_t.upgrade() {
                                ui.set_progress_text(SharedString::from(txt));
                                ui.set_progress_value(val);
                            }
                        });
                    });

                    if let Err(e) = install_res {
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(ui) = ui_thread.upgrade() {
                                ui.set_show_progress(false);
                                ui.set_error_text(SharedString::from(format!("Installation failed:\n{e}")));
                                ui.set_show_error(true);
                            }
                        });
                        return;
                    }

                    let rec_res = ModelDeploymentService::reconcile(&root, &m_clone, |_, _| {});
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = ui_thread.upgrade() {
                            ui.set_show_progress(false);
                            if let Ok(reconciled) = rec_res {
                                let rows: Vec<ModelInfo> = reconciled.installed.into_iter().map(|m| {
                                    ModelInfo {
                                        name: SharedString::from(m.name),
                                        model_type: SharedString::from(m.model_type),
                                        used_for: SharedString::from(m.used_for),
                                        author: SharedString::from(m.author),
                                        size_formatted: SharedString::from(format_size(m.size_bytes)),
                                        supports: Rc::new(slint::VecModel::from(m.supports.into_iter().map(SharedString::from).collect::<Vec<_>>())).into(),
                                    }
                                }).collect();
                                ui.set_models(Rc::new(slint::VecModel::from(rows)).into());
                                ui.set_total_size_formatted(SharedString::from(format_size(reconciled.total_bytes)));
                            }
                        }
                    });
                });
            });
        }

        {
            let ui_weak = ui.as_weak();
            let manifest = Arc::clone(&self.manifest);

            ui.on_remove_model(move |model_name| {
                let Some(ui) = ui_weak.upgrade() else { return; };
                let root = PathBuf::from(ui.get_current_location().to_string());
                let Some(model) = manifest.find_by_name(&model_name.to_string()).cloned() else { return; };

                let ui_thread = ui.as_weak();
                let m_clone = Arc::clone(&manifest);

                thread::spawn(move || {
                    let _ = ModelDeploymentService::remove(&root, &model);
                    let rec_res = ModelDeploymentService::reconcile(&root, &m_clone, |_, _| {});
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = ui_thread.upgrade() {
                            if let Ok(reconciled) = rec_res {
                                let rows: Vec<ModelInfo> = reconciled.installed.into_iter().map(|m| {
                                    ModelInfo {
                                        name: SharedString::from(m.name),
                                        model_type: SharedString::from(m.model_type),
                                        used_for: SharedString::from(m.used_for),
                                        author: SharedString::from(m.author),
                                        size_formatted: SharedString::from(format_size(m.size_bytes)),
                                        supports: Rc::new(slint::VecModel::from(m.supports.into_iter().map(SharedString::from).collect::<Vec<_>>())).into(),
                                    }
                                }).collect();
                                ui.set_models(Rc::new(slint::VecModel::from(rows)).into());
                                ui.set_total_size_formatted(SharedString::from(format_size(reconciled.total_bytes)));
                            }
                        }
                    });
                });
            });
        }
    }
}

fn main() -> Result<(), slint::PlatformError> {
    let app = AppController::new();
    app.run()
}

// ============================================================================
// CUDA Driver Helper Module
// ============================================================================

#[cfg(windows)]
mod cuda_driver {
    use std::ffi::{c_char, c_void};
    use std::os::windows::ffi::OsStrExt;

    type ModuleHandle = *mut c_void;
    type CuDriverGetVersion = unsafe extern "system" fn(*mut i32) -> i32;

    #[link(name = "kernel32")]
    extern "system" {
        fn LoadLibraryW(file_name: *const u16) -> ModuleHandle;
        fn GetProcAddress(module: ModuleHandle, procedure_name: *const c_char) -> *mut c_void;
        fn FreeLibrary(module: ModuleHandle) -> i32;
    }

    pub fn query_cuda_driver_version() -> Result<String, String> {
        unsafe {
            let library_name: Vec<u16> = std::ffi::OsStr::new("nvcuda.dll")
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();
            let module = LoadLibraryW(library_name.as_ptr());

            if module.is_null() {
                return Err("nvcuda.dll not loaded".to_string());
            }

            let procedure = GetProcAddress(module, b"cuDriverGetVersion\0".as_ptr() as *const c_char);
            if procedure.is_null() {
                let _ = FreeLibrary(module);
                return Err("cuDriverGetVersion not exported".to_string());
            }

            let get_version: CuDriverGetVersion = std::mem::transmute(procedure);
            let mut version_encoded = 0_i32;
            let status = get_version(&mut version_encoded);
            let _ = FreeLibrary(module);

            if status != 0 || version_encoded <= 0 {
                return Err(format!("CUDA query code {status}"));
            }

            Ok(format!("{}.{}", version_encoded / 1000, (version_encoded % 1000) / 10))
        }
    }
}